
def Evaluaredad(edad):

  if edad>18:
    print(f"{edad} años pasar!")

  elif edad<18:
    raise TypeError(f"{edad}años no es suficiente")

  elif edad>50:
    print(f"{edad} años pase!") 

Evaluaredad(17)        

    